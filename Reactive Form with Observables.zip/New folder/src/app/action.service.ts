import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({
  providedIn: 'root'
})

export class ActionService {

  messageSource;
  currentMessage;

  constructor() { 
    this.messageSource = new BehaviorSubject<any>(undefined);
    this.currentMessage = this.messageSource.asObservable();
  }

  triggerAddBtn(data: any) {
    this.messageSource.next(data);
  }

}
