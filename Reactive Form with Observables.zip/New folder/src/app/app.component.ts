import { Component, Input} from '@angular/core';
import { FormArray, FormGroup, FormControl, Validators } from '@angular/forms';
import { ActionService } from 'src/app/action.service';
import { Subscription } from 'rxjs';
import { SidebarComponent } from './sidebar/sidebar.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  @Input() condLogicDropdownData;

  subscription: Subscription = new Subscription();
  public sidebar: SidebarComponent;

  // operation type
  logicalOperation: any = ['equal to', 'not equal', 'greater than', 'less than', 'greater than or equal to', 'less than or equal to'];
  // operation name
  Operations: any = ['Add', 'Remove', 'Hide', 'Show', 'Enable', 'Disable','AddStyle','RemoveStyle','Mandatory','ShowMessage'];
  // sidebar options
  sidebaroptions : any = ['Customer', 'Name', 'Address', 'City', 'StateName'];
    
  fCondLogic: FormGroup;
  selectedWhenSection: any;
  whenSectionAfterChangeEvent = [];
  showError: boolean = false;
  showSuccess: boolean = false;
  dataSaved: boolean = false;
  currentButton: any = 'first';  

  constructor(private action : ActionService) {
  }

  ngOnInit() {
    this.fCondLogic = new FormGroup({
      condLogic: new FormArray([
        this.initcondLogic(),
      ])
    });
    
    if (this.action.currentMessage) {
      this.subscription = this.action.currentMessage.subscribe(data => {
        if (data) {
          this.logicalOperation.indexOf(data) === -1 ? this.logicalOperation.push(data): '';
          this.Operations.indexOf(data) === -1 ? this.Operations.push(data): '';          
        }
      })
    }
  }

  ngOnDestroy() {
    this.action.currentMessage.unsubscribe();
  }

  resetForm() {
    this.fCondLogic = new FormGroup({
      condLogic: new FormArray([
        this.initcondLogic(),
      ]),
    });
  }

  compare(val1, val2) {
    return val1.name === val2.name;
  }

  saveCondLogic() {
    if (this.fCondLogic.invalid) {
      this.showError = true;
      this.showSuccess = false;
      this.dataSaved = false;
    } else {
      this.showError = false;
      this.showSuccess = true;
      this.dataSaved = true;
    }
  }

  changeWhenSection(name) {
    this.selectedWhenSection = this.condLogicDropdownData.find(i => i.name === name);
  }

  initcondLogic() {
    return new FormGroup({
      when: new FormArray([
        this.initWhen()
      ]),
      then: new FormArray([
        this.initThen()
      ])
    });
  }

  initWhen() {
    return new FormGroup({
      whenSection: new FormControl(''),
      whenElementName: new FormControl(''),
      whenOperator: new FormControl(''),
      whenValue: new FormControl(''),
      whenCase: new FormControl('')
    });
  }

  initThen() {
    return new FormGroup({
      thenAction: new FormControl('', Validators.required),
      thenSection: new FormControl('', Validators.required),
      thenElementName: new FormControl('')
    });
  }

  addcondLogic() {
    const control = <FormArray>this.fCondLogic.get('condLogic');
    control.push(this.initcondLogic());
  }

  addWhen(j) {
    const control = <FormArray>this.fCondLogic.get('condLogic')['controls'][j].get('when');
    control.push(this.initWhen());

  }

  addThen(j) {
    const control = <FormArray>this.fCondLogic.get('condLogic')['controls'][j].get('then');
    control.push(this.initThen());
  }

  getcondLogic(form) {
    return form.controls.condLogic.controls;
  }
  getWhen(form) {
    return form.controls.when.controls;
  }
  getThen(form) {
    return form.controls.then.controls;
  }

  removeWhen(i, j) {
    const control = <FormArray>this.fCondLogic.get(['condLogic', i, 'when']);
    control.removeAt(j);
  }

  removeThen(i, j) {
    const control = <FormArray>this.fCondLogic.get(['condLogic', i, 'then']);
    control.removeAt(j);
  }

  removecondLogic(i) {
    const control = <FormArray>this.fCondLogic.get('condLogic');
    control.removeAt(i);

  }

  whenSectionChanged(i, j) {
    const whenSectionType = this.fCondLogic.get('condLogic')['controls'][i].get('when')['controls'][j].get('whenSection').value;
    this.whenSectionAfterChangeEvent = this.condLogicDropdownData.filter(p => p.name == whenSectionType);
  }
}
