import { Component, OnInit, Input } from '@angular/core';
import { ActionService } from 'src/app/action.service';


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})

export class SidebarComponent implements OnInit {
  // sidebar options
  sidebaroptions : any = ['Customer', 'Name', 'Address', 'City', 'StateName'];
  constructor(private action : ActionService) { }
  
  ngOnInit() {}

  addElementToObservableArray(item) {
    this.action.triggerAddBtn(item);
  }
}
